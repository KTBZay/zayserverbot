const ZayClient = class {
    constructor(){
        this.startconnection = class{
            constructor(ide_name, ide_id){
           if(ide_name === "Zay_MainCli"){
            const request = require('request')
            request.post('https://m608zrqq-2000.use.devtunnels.ms/', {form: {client_name: ide_name, client_id: ide_id}})
            console.log("ZayClient.main has created an a profile on the server");

           }else{
            console.log("Welcome to Zays Client, For your safety we keep your data private as it transfers between servers.")
            const request = require('request')
            request.post('https://m608zrqq-2000.use.devtunnels.ms/', {form: {client_name: ide_name, client_id: ide_id}})
           }
            this.createbot = (token, id) =>{
                request.post('https://m608zrqq-2000.use.devtunnels.ms/create', {form: {token: token, id:id}})
                console.log("Client created")
            }
            this.ping = () => {
                request.post('https://m608zrqq-2000.use.devtunnels.ms/ping')
                console.log("Service is running")
            }
        }
    }
    this.createServer = class {
        constructor(){
            this.create = function (name,port,opts){
                const request = require('request')   
                console.log("we created an application if you are approved your server should start next time you run you can use start")
                request.post('https://m608zrqq-2000.use.devtunnels.ms/createServer', {
                    form: {
                        name: name,
                        options: opts,
                        port: port
                    }
                })
            }
            this.start = function (name,port,opts){
                const request = require('request')
                console.log("Client started if apporved")
                request.post('https://m608zrqq-2000.use.devtunnels.ms/serverLogin', {
                    form: {
                        name: name,
                        options: opts,
                        port: port
                    }
                })
            }
            
        }
    }

    }
}

module.exports = {
    ZayClient
}