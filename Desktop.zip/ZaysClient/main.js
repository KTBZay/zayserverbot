const { ZayClient } = require(".");
const client = new ZayClient()
const bot = new client.createServer()
bot.start("Zays_MainCli", 2001, {admin: [], users: []})
