const { EmbedBuilder } = require("discord.js")

const Errorembed = new EmbedBuilder()
		.setTitle('Error')
		.addFields(
			
		)
		.setColor("Red")

module.exports = {
Errorembed
}