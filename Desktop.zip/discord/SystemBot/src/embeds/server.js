const { EmbedBuilder } = require('discord.js');
const os = require('os');
const host = {
    name: os.hostname(),
    machine: os.machine(),
    os: os.type()
}
const hostdata = new EmbedBuilder()
.setTitle('Host Data')
.addFields(
    {name:"Host Name", value:`${host.name}`},
    {name:"Host Machine", value:`${host.machine}`},
    {name:"Host OS", value:`${host.os}`}
)
.setColor("Green")

module.exports = {
    hostdata
}