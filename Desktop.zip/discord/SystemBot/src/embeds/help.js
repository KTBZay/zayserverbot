const {  EmbedBuilder } = require('discord.js');

const helpembed = new EmbedBuilder()
		.setTitle('Help Panel | v1 | ZaysServer')
		.addFields(
			{name: "/echo", value:"Echos back input", inline:true},
			{name: "/serverinfo", value:"Replys with discord server info", inline:true},
			{name: "/userinfo", value:"Replys with discord userinfo", inline:true},
			{name: "/server", value:"Sends data about the server", inline:true},
			{name: "/ping", value:"pings the bot", inline:true},
			{name: "/hello", value:"Greets you", inline:true},
			{name: "/magic", value:"Does Scary Things", inline:true},
			{name: "/serverping", value:"Pings Server", inline:true},
			{name: "/alerts", value:"Shows Current Alerts", inline:true},
			{name: "/create", value:"Creates a discord bot", inline:true},
			{name: "/help", value:"Shows this", inline:true},
			{name: "/kick", value:"Kicks a user", inline:true},
			{name: "/ban", value:"bans a user", inline:true},
		)
		.setColor("Green")

    module.exports = {
        helpembed
    }
