const { EmbedBuilder } = require("discord.js");

const connect = new EmbedBuilder()

    .setTitle("Connection Establish")
    .setColor("Green")
    .setDescription("We have connected you to the sql server\nYou should be able to run /collectdata [client_name]")

module.exports = {
    connect
}