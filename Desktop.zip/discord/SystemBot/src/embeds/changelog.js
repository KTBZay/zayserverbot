const {  EmbedBuilder } = require('discord.js');
const changelogembed = new EmbedBuilder()
.setTitle('Change log')
.addFields(
    {name: "v1.0", value:"- Fixed Bugs \n - Added 4 new commands", inline:true},
    {name: "v1.2", value:"- Fixed Bugs \n - Added 2 new commands", inline:true},
    {name: "v1.3", value:"- Added Server 1 into Server 2 ", inline:true},
    {name: "v1.4", value:"- Fixed bugs \n - Removed Certain Backend Functions", inline:true},
    {name: "v1.4.1", value:"- Fixed bugs \n -Made embeds have there own file \n - Creating a new message system", inline:true},
    {name: "v1.4.2", value:"- Fixed bugs \n - Made embeds color coded \n - Added a custom log system on backend to track who used command", inline:true},
    {name: "v1.4.3", value:"- Fixed bugs \n - Added Sqlite3 Server \n - Made it so /create will not go offline", inline:true},
    {name: "v1.4.4", value:"- Restructured Root.\n - Added Kick Cmd + 2 more\n - Making warn system", inline:true},
    {name: "v1.4.5", value:"- Updated Embeds", inline:true},
)
.setColor("Green")
module.exports = {
    changelogembed
}