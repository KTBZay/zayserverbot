const { EmbedBuilder } = require("discord.js")

const alertsembed = new EmbedBuilder()
		.setTitle('Current Maintence Alerts')
		.addFields(
			{name: "12/18/23", value:"No alerts found", inline: false},
			{name: "12/19/23", value:"No alerts found", inline: false},
			{name: "12/20/23", value:"No alerts found", inline: false},
			{name: "12/21/23", value:"No alerts found", inline: false},
		)
		.setColor("Green")

module.exports = {
alertsembed
}