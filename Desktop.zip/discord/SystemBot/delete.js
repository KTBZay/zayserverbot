const { REST, Routes } = require('discord.js');
const { token,id } = require('./config.json');

const rest = new REST().setToken(token);
rest.put(Routes.applicationCommands(id), { body: [] })
	.then(() => console.log('Successfully deleted all application commands.'))
	.catch(console.error);