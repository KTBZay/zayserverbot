const sqlite3 = require('sqlite3').verbose()
const db = new sqlite3.Database('../databases/client_data.db', (err)=>{
    if(err) throw err;
})
const publicdb = new sqlite3.Database('../databases/public.db', (err)=>{
  if(err) throw err;
})
module.exports = {
  db,
  publicdb
}