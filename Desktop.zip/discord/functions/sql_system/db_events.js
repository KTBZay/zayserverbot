const {db, publicdb} = require("./db");

db.on("change", (type,database,table,rowid)=>{
    console.log(`Client has ${type} at ${database} table ${table} row ${rowid}`);
    console.log("Clearing console")
    console.clear()
})
db.on("close", ()=>{
    console.log('Client closed the connection')
})
db.on('error', (err)=>{
    console.log("there was an error at "+ err.stack + " The error message is " + err.message);
})
db.on("open", ()=>{
    console.log("Client has opened the database")
})
db.on("profile", (sql,time)=>{
    console.log("Client has access a profile" + sql + " \n" + time)
})
db.on("trace", (sql)=>{
    console.log("A client ran " + sql)
})

publicdb.on("change", (type,database,table,rowid)=>{
    console.log(`Client has ${type} at ${database} table ${table} row ${rowid}`);
    console.log("Clearing console")
    console.clear()
})
publicdb.on("close", ()=>{
    console.log('Client closed the connection')
})
publicdb.on('error', (err)=>{
    console.log("there was an error at "+ err.stack + " The error message is " + err.message);
})
publicdb.on("open", ()=>{
    console.log("Client has opened the database")
})
publicdb.on("profile", (sql,time)=>{
    console.log("Client has access a profile" + sql + " \n" + time)
})
publicdb.on("trace", (sql)=>{
    console.log("A client ran " + sql)
})