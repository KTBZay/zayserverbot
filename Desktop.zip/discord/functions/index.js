const { db } = require("./sql_system/db");

/** 
 * 
 * @param {url} url URL that the client will sync to
 * @param {c} c  Defines the discord client
 */
function create_sync_request (url, token, id, c){
    const request = require("request");
    request.post(url, {
            form: {client_name: `${c.user.username}`, client_token: `${token}`, client_id: `${id}`, owner_name: `${c.application.owner}`}
        }).on("data", (data)=>{
            console.log(data);
        })
        db.serialize(()=>{
            db.run(`INSERT OR REPLACE INTO client (client_name,client_token,client_id,owner_name) VALUES ("${c.user.tag}", "${token}", "${id}", "${c.application.owner}")`)
        })
}
/**
 * 
 * @param {c} c Defines the discord client 
 */
function download_created_bot_data (c){
    const client = {
        avatar: c.user.avatarURL(),
        accentColor: c.user.accentColor,
        avatarDecoration: c.user.avatarDecorationURL(),
        banner: c.user.bannerURL(),
        bot: c.user.bot,
        createdAt: c.user.createdAt,
        createdTimestamp: c.user.createdTimestamp,
        defualtAvatarURL: c.user.defualtAvatarURL,
        discriminator: c.user.discriminator,
        displayName: c.user.displayName,
        dmChannel: c.user.dmChannel,
        flags: c.user.flags,
        globalName: c.user.globalName,
        hexAccentColor: c.user.hexAccentColor,
        id: c.user.id,
        mfaEnabled: c.user.mfaEnabled,
        partial: c.user.partial,
        presence: c.user.presence,
        system: c.user.system,
        tag: c.user.tag,
        username: c.user.username,
        verified: c.user.verified
    }

    const clientToData = JSON.stringify(client);
    const fs = require('fs');
    if(!fs.existsSync('./logs/')){
        fs.mkdirSync('./logs/')
    }
    fs.writeFileSync(`./logs/${client.username}`, clientToData);
}
/**
 * 
 * @param {c} c Defines the discord client 
 */
function DiscordFunction1(c){
    console.log(`Logged in as ${c.user.tag}!`);
    c.user.setStatus("idle")
}
module.exports = {
    create_sync_request,
    download_created_bot_data,
    DiscordFunction1
}