const { create_sync_request } = require('../functions');
const {clienttoken} = require('./config.json');
try{
    console.log('Trying to resolve ' + clienttoken);
    const path = require('path');
    const fs = require('fs');
    const { Client, Events, GatewayIntentBits, Collection } = require('discord.js');
    const client = new Client({ intents: [GatewayIntentBits.Guilds] });
    client.commands = new Collection();
    client.once(Events.ClientReady, c => {
        create_sync_request('http://localhost:2000/', c);
        console.log(`Ready! We resolved ${clienttoken} & logged into ${c.user.tag}`);
    });
    client.on(Events.Error, (err)=>{
        console.log("We have found an error " + err.name + " We will restart the bat");
        throw "Please close window and restart the bot"
    })
    const foldersPath = path.join(__dirname, 'commands');
    const commandFolders = fs.readdirSync(foldersPath);

    for (const folder of commandFolders) {
        const commandsPath = path.join(foldersPath, folder);
        const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
        for (const file of commandFiles) {
            const filePath = path.join(commandsPath, file);
            const command = require(filePath);
            // Set a new item in the Collection with the key as the command name and the value as the exported module
            if ('data' in command && 'execute' in command) {
                client.commands.set(command.data.name, command);
            } else {
                console.log(`[WARNING] The command at ${filePath} is missing a required "data" or "execute" property.`);
            }
        }
    }
    client.on(Events.InteractionCreate, async interaction => {
        if (!interaction.isChatInputCommand()) return;
        
        const command = interaction.client.commands.get(interaction.commandName);
    
        if (!command) {
            console.error(`No command matching ${interaction.commandName} was found.`);
            return;
        }
    
        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(error);
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: 'There was an error while executing this command!', ephemeral: true });
            } else {
                await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
            }
        }
    });
    client.login(clienttoken)
    } catch (e) {
         throw e
}

