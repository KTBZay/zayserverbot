const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { rulesembed } = require("../../lib/rules.embed");
module.exports = {
    data: new SlashCommandBuilder()
         .setName("rules")
         .setDescription("Rules of the server")
         .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute (interaction) {
        interaction.reply({embeds:[rulesembed] })
    }
}