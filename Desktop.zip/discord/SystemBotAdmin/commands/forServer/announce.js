const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
module.exports = {
	data: new SlashCommandBuilder()
		.setName('announce')
		.setDescription('Announces to the server!')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addStringOption(option => 
            option.setName('aname') 
            .setDescription("Announcement Name")
            .setRequired(true)
            )
        .addStringOption(option => 
            option.setName('announcementdesc') 
            .setDescription("Announcement Description)")
            .setRequired(true)
         ),   
	async execute(interaction) {
            const aname = interaction.options.getString('aname');
            const adesc = interaction.options.getString('announcementdesc');

            const rules = new EmbedBuilder()
            .addFields(
                {name:"Announcement: ", value:`${adesc}`}
            )
            .setColor('Green')

            interaction.reply({embeds:[rules]})
	},
};