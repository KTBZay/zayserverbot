const { REST, Routes } = require('discord.js');
const { clientid, guildid, clienttoken } = require('./config.json');

const rest = new REST().setToken(clienttoken);
rest.put(Routes.applicationCommands(clientid), { body: [] })
	.then(() => console.log('Successfully deleted all application commands.'))
	.catch(console.error);