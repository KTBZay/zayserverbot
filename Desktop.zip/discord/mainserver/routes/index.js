var express = require('express');
const {db}= require('../../functions/sql_system/db');
const fs = require('fs');
const dbEvents = require('../../functions/sql_system/db_events');
const { create_sync_request } = require('../../functions');
var router = express.Router();
/* GET home page. */
router.get('/', function(req, res, next) {
  res.status(200).send({
    client: "Started"
  })
});
router.post('/', (req,res)=>{
    const {client_name, client_id} = req.body;
    res.status(200).setHeader("CLIENT", "application/discord")
    console.log(`Server accepted requests from \n${client_name}\n${client_id}\n` + res.getHeaderNames() + " " + res.statusCode);
    const data = `Server accepted requests from \n${client_name}\n${client_id}\n ` + res.getHeaderNames() + " " + res.statusCode
    if(!fs.existsSync('../logs/')){
      fs.mkdirSync('../logs')
    }
    fs.writeFileSync(`../logs/express.${client_name}.init.req.${Date.now()}.log`, data)
})
router.post('/create', (req,res,next) =>{
    const  {token,id} = req.body;
    const {DeployTask} = require('./application_deploy')
    const {RunTask} = require('./application')
    DeployTask(token,id);
    RunTask(token,id)
    create_sync_request('http://localhost:2000/approve', {user:{tag: "Approval System", id:"09128390-281930-328321"}})
    res.setHeader("accept",true).send({
      message: "Client is running"
    })
    fs.writeFileSync(`../logs/express.${client_name}.create.req.${Date.now()}.log`, data)
  })
router.post("/approve", (req,res)=>{
    const {client_name, client_id} = req.body;

    res.send("Service has approved the client " + client_name)
    fs.writeFileSync(`../logs/express.${client_name}.approval.req.${Date.now()}.log`, data)
})
router.post("/edit", (req,res)=>{
    const {id, token} = req.body;
    db.serialize(()=>{
        db.run(`REPLACE INTO clients(id,token) VALUES ("${id}", "${token}")`, (err)=>{
            
        });

    })
    fs.writeFileSync(`../logs/express.${client_name}.edit.req.${Date.now()}.log`, data)
})
router.post('/ping', (req,res)=>{
  res.status(200).send("Online")
})
router.post('/createServer', (req,res)=>{
  const {name,port,settings} = req.body;

  if(!fs.existsSync('./application')){
    fs.mkdirSync('./application')
  }
  fs.writeFileSync(`./application/${name}.app.json`, `{"name": "${name}",\n "port": "${port}",\n "settings": "${settings}", "isApproved": false}`)

})
router.post('/serverLogin', (req,res)=>{
  const {name,port,settings} = req.body;

  try {
    const {isApproved} = require(`./application/${name}.app`);

    if(isApproved === true){
      const server = express();
      server.get('/', function(req, res, next) {
        res.status(200).send({
          client: "Started"
        })
      });
      server.post('/', (req,res)=>{
          const {client_name, client_id} = req.body;
          res.status(200).setHeader("CLIENT", "application/discord")
          console.log(`Server accepted requests from \n${client_name}\n${client_id}\n` + res.getHeaderNames() + " " + res.statusCode);
          const data = `Server accepted requests from \n${client_name}\n${client_id}\n ` + res.getHeaderNames() + " " + res.statusCode
          if(!fs.existsSync('../logs/')){
            fs.mkdirSync('../logs')
          }
          fs.writeFileSync(`../logs/express.${client_name}.init.req.${Date.now()}.log`, data)
      })
      server.post('/create', (req,res,next) =>{
          const  {token,id} = req.body;
          const {DeployTask} = require('./application_deploy')
          const {RunTask} = require('./application')
          DeployTask(token,id);
          RunTask(token,id)
          create_sync_request('http://localhost:2000/approve', {user:{tag: "Approval System", id:"09128390-281930-328321"}})
          res.setHeader("accept",true).send({
            message: "Client is running"
          })
          fs.writeFileSync(`../logs/express.${client_name}.create.req.${Date.now()}.log`, data)
        })
        server.post("/approve", (req,res)=>{
          const {client_name, client_id} = req.body;
      
          res.send("Service has approved the client " + client_name)
          fs.writeFileSync(`../logs/express.${client_name}.approval.req.${Date.now()}.log`, data)
      })
      server.post("/edit", (req,res)=>{
          const {id, token} = req.body;
          db.serialize(()=>{
              db.run(`REPLACE INTO clients(id,token) VALUES ("${id}", "${token}")`, (err)=>{
                  
              });
      
          })
          fs.writeFileSync(`../logs/express.${client_name}.edit.req.${Date.now()}.log`, data)
      })
      server.post('/ping', (req,res)=>{
        res.status(200).send("Online")
      })

      server.listen(port, (err)=>{
        if(err) throw err;
        console.log(name + " Server is online")
      })
    }
  } catch (error) {
    
  }
})
module.exports = router;
