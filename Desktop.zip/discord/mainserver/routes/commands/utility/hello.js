const { SlashCommandBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('hello')
		.setDescription('With a statement'),
	async execute(interaction) {
		await interaction.reply('How are you?');
        setTimeout(() => {
         interaction.editReply({content: "Thats Good!", tts:true})
        }, 10000);
	},
};