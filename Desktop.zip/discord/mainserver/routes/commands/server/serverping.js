const { SlashCommandBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('serverping')
		.setDescription('Replies with Server Ping!'),
	async execute(interaction) {
		await interaction.reply(`ms: ${interaction.client.ws.ping}`);
	},
};
