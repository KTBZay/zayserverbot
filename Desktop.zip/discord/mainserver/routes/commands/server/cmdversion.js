const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('cmdversion')
		.setDescription('Replies with help!'),
	async execute(interaction) {
		const helpembed = new EmbedBuilder()
		.setTitle('Help Panel | v1 | ZaysServer')
		.addFields(
			{name: "/echo", value:"1.0.0"},
			{name: "/serverinfo", value:"1.0.0"},
			{name: "/userinfo", value:"1.0.0"},
			{name: "/server", value:"1.0.0"},
			{name: "/ping", value:"1.0.0"},
			{name: "/hello", value:"1.0.0"},
			{name: "/magic", value:"1.0.0"},
			{name: "/serverping", value:"1.0.0"},
			{name: "/alerts", value:"1.0.0"},
			{name: "/help", value:"1.0.1"}
			
		)
		await interaction.reply({embeds:[helpembed]});
	},
};