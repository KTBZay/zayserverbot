const { SlashCommandBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('help')
		.setDescription('Replies with help!'),
	async execute(interaction) {
		await interaction.reply('Current Command Folders: Server, Utility  \n Current Command Set: help, ping, echo, ban');
	},
};
