const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('userinfo')
		.setDescription('Provides information about the user.'),
	async execute(interaction) {
		const userinfo = new EmbedBuilder()
        .setTitle('User info')
        .setDescription('Displays User Info')
        .addFields(
            {name:"Ran By", value:`${interaction.user.username}`},
            {name:'Returned Data', value: `Joined at:${interaction.member.joinedAt}\n DisplayName: ${interaction.member.displayName}\n ID: ${interaction.member.id}`}
        )
		await interaction.reply({embeds: [userinfo]});
	},
};