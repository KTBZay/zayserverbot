var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Zays Bot Creator' });
});
router.post('/create', (req,res,next) =>{
  const  {token,id} = req.body;
  const {DeployTask} = require('./application_deploy')
  const {RunTask} = require('./application')
  DeployTask(token,id);
  RunTask(token,id)
  res.status(200).send({
    message: "Client is online!"
  })
})
module.exports = router;
