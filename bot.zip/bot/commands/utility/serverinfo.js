const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('serverinfo')
		.setDescription('Provides information about the server.'),
	async execute(interaction) {
		const serverinfo = new EmbedBuilder()
        .setTitle('Server info')
        .setDescription('Displays server Info')
        .addFields(
            {name:"Ran By", value:`${interaction.user.username}`},
            {name:'Returned Data', value: `Guild Name: :${interaction.guild.name}\n Guild Description: ${interaction.guild.description}\n Guild Commands: ${interaction.guild.commands}\n Created At: ${interaction.guild.createdAt}`}
        )
		await interaction.reply({embeds: [serverinfo]});
	},
};