const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('help')
		.setDescription('Replies with help!'),
	async execute(interaction) {
		const helpembed = new EmbedBuilder()
		.setTitle('Help Panel | v1 | ZaysServer')
		.addFields(
			{name: "/echo", value:"Echos back input"},
			{name: "/serverinfo", value:"Replys with discord server info"},
			{name: "/userinfo", value:"Replys with discord userinfo"},
			{name: "/server", value:"Sends data about the server"},
			{name: "/ping", value:"pings the bot"},
			{name: "/hello", value:"Greets you"},
			{name: "/magic", value:"Does Scary Things"},
			{name: "/serverping", value:"Pings Server"},
			{name: "/alerts", value:"Shows Current Alerts"},
			{name: "/help", value:"Shows this"}
		)
		await interaction.reply({embeds:[helpembed]});
	},
};
