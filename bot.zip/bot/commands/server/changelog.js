const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('changelog')
		.setDescription('Replies with changlog!'),
	async execute(interaction) {
		const helpembed = new EmbedBuilder()
		.setTitle('Changlog')
		.addFields(
			{name: "v1.0", value:"-Fixed Bugs \n -Added 4 new commands"},
			{name: "v1.2", value:"-Fixed Bugs \n -Added 2 new commands"},
			{name: "v1.3", value:"-Added Server 1 into Server 2 "}
		)
		await interaction.reply({embeds:[helpembed]});
	},
};
