const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('alerts')
		.setDescription('Replies with changlog!'),
	async execute(interaction) {
		const helpembed = new EmbedBuilder()
		.setTitle('Changlog')
		.addFields(
			{name: "Alert", value:"Server 1 will be under maintence", inline: true}
		)
		await interaction.reply({embeds:[helpembed]});
	},
};
