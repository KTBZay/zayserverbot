const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('server')
		.setDescription('Replies with some of the hosts details!'),
	async execute(interaction) {
        const os = require('os');
        const host = {
            name: os.hostname(),
            machine: os.machine(),
            os: os.type()
        }
        const hostdata = new EmbedBuilder()
        .setColor('Aqua')
        .setTitle('Host Data')
        .addFields(
            {name:"Host Name", value:`${host.name}`},
            {name:"Host Machine", value:`${host.machine}`},
            {name:"Host OS", value:`${host.os}`}
        )

        interaction.reply({embeds: [hostdata] });
        }
    }
